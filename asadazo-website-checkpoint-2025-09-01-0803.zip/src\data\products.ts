import type { Product } from '../types';

export const products: Product[] = [
  // Meat (Carne) - Beef cuts
  {
    id: 'entrana',
    name: 'Entraña',
    price: 24,
    pricePerKg: true,
    minPack: 0.5,
    stock: 10,
    category: 'meat',
    description: 'Premium skirt steak, perfect for grilling',
    image: '/images/entrana.jpg'
  },
  {
    id: 'cuadril',
    name: 'Cuadril',
    price: 24,
    pricePerKg: true,
    minPack: 0.5,
    stock: 8,
    category: 'meat',
    description: 'Top sirloin, tender and flavorful',
    image: '/images/cuadril.jpg'
  },
  {
    id: 'vacio',
    name: 'Vacío',
    price: 22,
    pricePerKg: true,
    minPack: 0.5,
    stock: 12,
    category: 'meat',
    description: 'Flank steak, perfect for asado',
    image: '/images/vacio.jpg'
  },
  {
    id: 'bola-de-lomo',
    name: 'Bola de Lomo',
    price: 26,
    pricePerKg: true,
    minPack: 0.5,
    stock: 6,
    category: 'meat',
    description: 'Eye of round, lean and tender',
    image: '/images/bola-de-lomo.jpg'
  },
  {
    id: 'peceto',
    name: 'Peceto',
    price: 26,
    pricePerKg: true,
    minPack: 0.5,
    stock: 9,
    category: 'meat',
    description: 'Top round, excellent for roasting',
    image: '/images/peceto.jpg'
  },
  {
    id: 'asado',
    name: 'Asado',
    price: 22,
    pricePerKg: true,
    minPack: 1,
    stock: 15,
    category: 'meat',
    description: 'Short ribs, traditional asado cut',
    image: '/images/asado.jpg'
  },
  {
    id: 'tira-de-asado',
    name: 'Tira de Asado',
    price: 20,
    pricePerKg: true,
    minPack: 1,
    stock: 18,
    category: 'meat',
    description: 'Cross-cut short ribs, classic asado',
    image: '/images/tira-de-asado.jpg'
  },
  {
    id: 'bife-de-chorizo',
    name: 'Bife de Chorizo',
    price: 28,
    pricePerKg: true,
    minPack: 0.3,
    stock: 14,
    category: 'meat',
    description: 'Strip steak, premium grilling cut',
    image: '/images/bife-de-chorizo.jpg'
  },
  {
    id: 'ojo-de-bife',
    name: 'Ojo de Bife',
    price: 30,
    pricePerKg: true,
    minPack: 0.3,
    stock: 12,
    category: 'meat',
    description: 'Ribeye steak, marbled and juicy',
    image: '/images/ojo-de-bife.jpg'
  },
  {
    id: 'lomo',
    name: 'Lomo',
    price: 32,
    pricePerKg: true,
    minPack: 0.3,
    stock: 8,
    category: 'meat',
    description: 'Tenderloin, the most tender cut',
    image: '/images/lomo.jpg'
  },
  {
    id: 'colita-de-cuadril',
    name: 'Colita de Cuadril',
    price: 26,
    pricePerKg: true,
    minPack: 0.5,
    stock: 10,
    category: 'meat',
    description: 'Tri-tip, flavorful and versatile',
    image: '/images/colita-de-cuadril.jpg'
  },
  {
    id: 'paleta',
    name: 'Paleta',
    price: 18,
    pricePerKg: true,
    minPack: 1,
    stock: 20,
    category: 'meat',
    description: 'Chuck roast, perfect for slow cooking',
    image: '/images/paleta.jpg'
  },
  {
    id: 'falda',
    name: 'Falda',
    price: 16,
    pricePerKg: true,
    minPack: 0.5,
    stock: 15,
    category: 'meat',
    description: 'Skirt steak, great for tacos',
    image: '/images/falda.jpg'
  },
  {
    id: 'matambre',
    name: 'Matambre',
    price: 20,
    pricePerKg: true,
    minPack: 0.5,
    stock: 12,
    category: 'meat',
    description: 'Flank steak roll, traditional preparation',
    image: '/images/matambre.jpg'
  },
  {
    id: 'picaña',
    name: 'Picaña',
    price: 34,
    pricePerKg: true,
    minPack: 0.5,
    stock: 6,
    category: 'meat',
    description: 'Top sirloin cap, Brazilian favorite',
    image: '/images/picana.jpg'
  },

  // Pork (Cerdo) cuts
  {
    id: 'matambre-cerdo',
    name: 'Matambre de Cerdo',
    price: 21,
    pricePerKg: true,
    minPack: 0.5,
    stock: 7,
    category: 'pork',
    description: 'Pork flank, perfect for grilling',
    image: '/images/matambre-cerdo.jpg'
  },
  {
    id: 'bondiola',
    name: 'Bondiola',
    price: 19,
    pricePerKg: true,
    minPack: 0.5,
    stock: 10,
    category: 'pork',
    description: 'Pork shoulder, great for roasting',
    image: '/images/bondiola.jpg'
  },
  {
    id: 'panceta',
    name: 'Panceta',
    price: 22,
    pricePerKg: true,
    minPack: 0.3,
    stock: 8,
    category: 'pork',
    description: 'Pork belly, crispy and flavorful',
    image: '/images/panceta.jpg'
  },
  {
    id: 'costilla-cerdo',
    name: 'Costilla de Cerdo',
    price: 18,
    pricePerKg: true,
    minPack: 0.5,
    stock: 12,
    category: 'pork',
    description: 'Pork ribs, perfect for BBQ',
    image: '/images/costilla-cerdo.jpg'
  },
  {
    id: 'lomo-cerdo',
    name: 'Lomo de Cerdo',
    price: 24,
    pricePerKg: true,
    minPack: 0.5,
    stock: 9,
    category: 'pork',
    description: 'Pork tenderloin, lean and tender',
    image: '/images/lomo-cerdo.jpg'
  },
  {
    id: 'chuleta-cerdo',
    name: 'Chuleta de Cerdo',
    price: 20,
    pricePerKg: true,
    minPack: 0.3,
    stock: 15,
    category: 'pork',
    description: 'Pork chops, classic cut',
    image: '/images/chuleta-cerdo.jpg'
  },
  {
    id: 'pernil',
    name: 'Pernil',
    price: 17,
    pricePerKg: true,
    minPack: 1,
    stock: 6,
    category: 'pork',
    description: 'Pork leg, traditional roast',
    image: '/images/pernil.jpg'
  },

  // Sausages (Embutidos)
  {
    id: 'chorizo-criollo',
    name: 'Chorizo Criollo',
    price: 18,
    pricePerKg: true,
    minPack: 0.3,
    stock: 20,
    category: 'sausages',
    description: 'Traditional Argentine chorizo',
    image: '/images/chorizo-criollo.jpg'
  },
  {
    id: 'morcilla',
    name: 'Morcilla',
    price: 18,
    pricePerKg: true,
    minPack: 0.3,
    stock: 15,
    category: 'sausages',
    description: 'Blood sausage, rich and flavorful',
    image: '/images/morcilla.jpg'
  },
  {
    id: 'chorizo-parrillero',
    name: 'Chorizo Parrillero',
    price: 19,
    pricePerKg: true,
    minPack: 0.3,
    stock: 18,
    category: 'sausages',
    description: 'Grilling chorizo, perfect for asado',
    image: '/images/chorizo-parrillero.jpg'
  },
  {
    id: 'salchicha-parrillera',
    name: 'Salchicha Parrillera',
    price: 16,
    pricePerKg: true,
    minPack: 0.3,
    stock: 25,
    category: 'sausages',
    description: 'Grilling sausages, classic asado',
    image: '/images/salchicha-parrillera.jpg'
  },
  {
    id: 'longaniza',
    name: 'Longaniza',
    price: 20,
    pricePerKg: true,
    minPack: 0.3,
    stock: 12,
    category: 'sausages',
    description: 'Long sausage, traditional style',
    image: '/images/longaniza.jpg'
  },
  {
    id: 'butifarra',
    name: 'Butifarra',
    price: 17,
    pricePerKg: true,
    minPack: 0.3,
    stock: 14,
    category: 'sausages',
    description: 'Catalan-style sausage',
    image: '/images/butifarra.jpg'
  },
  {
    id: 'salame',
    name: 'Salame',
    price: 25,
    pricePerKg: true,
    minPack: 0.2,
    stock: 8,
    category: 'sausages',
    description: 'Dry-cured salami',
    image: '/images/salame.jpg'
  },

  // Achuras (Offal)
  {
    id: 'chinchulines',
    name: 'Chinchulines',
    price: 32,
    pricePerKg: true,
    minPack: 0.3,
    stock: 5,
    category: 'achuras',
    description: 'Small intestines, grilled to perfection',
    image: '/images/chinchulines.jpg'
  },
  {
    id: 'molleja',
    name: 'Molleja',
    price: 45,
    pricePerKg: true,
    minPack: 0.2,
    stock: 3,
    category: 'achuras',
    description: 'Sweetbreads, a delicacy',
    image: '/images/molleja.jpg'
  },
  {
    id: 'riñones',
    name: 'Riñones',
    price: 28,
    pricePerKg: true,
    minPack: 0.2,
    stock: 4,
    category: 'achuras',
    description: 'Kidneys, rich and flavorful',
    image: '/images/rinones.jpg'
  },
  {
    id: 'higado',
    name: 'Hígado',
    price: 15,
    pricePerKg: true,
    minPack: 0.3,
    stock: 8,
    category: 'achuras',
    description: 'Liver, nutritious and tasty',
    image: '/images/higado.jpg'
  },
  {
    id: 'corazon',
    name: 'Corazón',
    price: 22,
    pricePerKg: true,
    minPack: 0.2,
    stock: 6,
    category: 'achuras',
    description: 'Heart, tender and lean',
    image: '/images/corazon.jpg'
  },
  {
    id: 'lengua',
    name: 'Lengua',
    price: 35,
    pricePerKg: true,
    minPack: 0.3,
    stock: 4,
    category: 'achuras',
    description: 'Beef tongue, tender when cooked',
    image: '/images/lengua.jpg'
  },
  {
    id: 'criadillas',
    name: 'Criadillas',
    price: 40,
    pricePerKg: true,
    minPack: 0.2,
    stock: 2,
    category: 'achuras',
    description: 'Testicles, traditional delicacy',
    image: '/images/criadillas.jpg'
  },
  {
    id: 'tripa-gorda',
    name: 'Tripa Gorda',
    price: 18,
    pricePerKg: true,
    minPack: 0.3,
    stock: 7,
    category: 'achuras',
    description: 'Large intestines, for stuffing',
    image: '/images/tripa-gorda.jpg'
  },
  {
    id: 'sesos',
    name: 'Sesos',
    price: 38,
    pricePerKg: true,
    minPack: 0.2,
    stock: 3,
    category: 'achuras',
    description: 'Brains, creamy texture',
    image: '/images/sesos.jpg'
  },

];

export const getProductsByCategory = (category: Product['category']) => {
  return products.filter(product => product.category === category);
};

export const getProductById = (id: string) => {
  return products.find(product => product.id === id);
};

export const getCategories = () => {
  return [
    { id: 'all', name: 'All Products', label: 'Todos los Productos' },
    { id: 'meat', name: 'Beef', label: 'Carne de Res' },
    { id: 'pork', name: 'Pork', label: 'Cerdo' },
    { id: 'sausages', name: 'Sausages', label: 'Embutidos' },
    { id: 'achuras', name: 'Offal', label: 'Achuras' }
  ];
};
