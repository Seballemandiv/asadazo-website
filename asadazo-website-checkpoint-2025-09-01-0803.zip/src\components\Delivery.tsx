import React from 'react';
import { MapPin, Clock, Truck } from 'lucide-react';

const Delivery: React.FC = () => {
  return (
    <section id="delivery" className="section">
      <div className="container">
        <h2 className="text-center mb-lg">Delivery & Pickup</h2>
        
        <div className="delivery-content">
          <div className="delivery-info">
            <div className="info-card">
              <Truck className="info-icon" />
              <h3>Amsterdam Delivery</h3>
              <p>€15 delivery fee</p>
              <p>Free delivery for orders over €80</p>
              <p>Delivery within 24-48 hours</p>
            </div>
            
            <div className="info-card">
              <MapPin className="info-icon" />
              <h3>Pickup Option</h3>
              <p>Amsterdam Oost</p>
              <p>Always available</p>
              <p>No additional cost</p>
            </div>
            
            <div className="info-card">
              <Clock className="info-icon" />
              <h3>Other Areas</h3>
              <p>Delivery by consultation</p>
              <p>Contact us for pricing</p>
              <p>Custom delivery times</p>
            </div>
          </div>
          
          <div className="delivery-details">
            <h3>Cold Chain & Packaging</h3>
            <p>
              All our products are carefully packaged to maintain the perfect temperature 
              during transport. We use specialized insulated packaging to ensure your 
              meat arrives in perfect condition.
            </p>
            <ul>
              <li>Insulated packaging</li>
              <li>Temperature monitoring</li>
              <li>Fresh delivery guarantee</li>
              <li>Eco-friendly materials</li>
            </ul>
          </div>
        </div>
      </div>


    </section>
  );
};

export default Delivery;
