import { useState } from 'react';
import { ShoppingCart, Plus, Edit, Trash2, Save, X as CloseIcon, LogOut, Package } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import type { Product, Order } from '../types';
import { products as initialProducts } from '../data/products';

// Mock data for orders
const MOCK_ORDERS: Order[] = [
  {
    id: '1',
    userId: '2',
    items: [
      {
        product: {
          id: '1',
          name: 'Entraña',
          price: 25.99,
          pricePerKg: true,
          minPack: 0.5,
          stock: 10,
          category: 'meat'
        },
        quantity: 1
      }
    ],
    total: 25.99,
    deliveryFee: 5.00,
    deliveryAddress: {
      street: '123 Main St',
      city: 'Amsterdam',
      postalCode: '1000 AA',
      country: 'Netherlands'
    },
    status: 'delivered',
    createdAt: new Date('2024-01-20'),
    deliveryDate: new Date('2024-01-22'),
    paymentMethod: {
      id: '1',
      type: 'card',
      last4: '1234',
      brand: 'Visa',
      isDefault: true
    }
  },
  {
    id: '2',
    userId: '2',
    items: [
      {
        product: {
          id: '2',
          name: 'Vacío',
          price: 28.99,
          pricePerKg: true,
          minPack: 0.5,
          stock: 8,
          category: 'meat'
        },
        quantity: 1.5
      }
    ],
    total: 43.49,
    deliveryFee: 5.00,
    deliveryAddress: {
      street: '123 Main St',
      city: 'Amsterdam',
      postalCode: '1000 AA',
      country: 'Netherlands'
    },
    status: 'preparing',
    createdAt: new Date('2024-01-25'),
    paymentMethod: {
      id: '1',
      type: 'card',
      last4: '1234',
      brand: 'Visa',
      isDefault: true
    }
  }
];

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [orders] = useState<Order[]>(MOCK_ORDERS);
  const [activeTab, setActiveTab] = useState<'products' | 'orders'>('products');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '',
    price: 0,
    pricePerKg: true,
    minPack: 0.5,
    stock: 0,
    category: 'meat'
  });

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleAddProduct = () => {
    if (newProduct.name && newProduct.price && newProduct.category) {
      const product: Product = {
        id: Date.now().toString(),
        name: newProduct.name,
        price: newProduct.price,
        pricePerKg: newProduct.pricePerKg || true,
        minPack: newProduct.minPack || 0.5,
        stock: newProduct.stock || 0,
        category: newProduct.category as 'meat' | 'pork' | 'sausages' | 'achuras',
        image: newProduct.image || ''
      };
      setProducts([...products, product]);
      setNewProduct({
        name: '',
        price: 0,
        pricePerKg: true,
        minPack: 0.5,
        stock: 0,
        category: 'meat'
      });
      setIsAddModalOpen(false);
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setNewProduct(product);
    setIsEditModalOpen(true);
  };

  const handleUpdateProduct = () => {
    if (editingProduct && newProduct.name && newProduct.price && newProduct.category) {
      const updatedProduct: Product = {
        ...editingProduct,
        name: newProduct.name,
        price: newProduct.price,
        pricePerKg: newProduct.pricePerKg || true,
        minPack: newProduct.minPack || 0.5,
        stock: newProduct.stock || 0,
        category: newProduct.category as 'meat' | 'pork' | 'sausages' | 'achuras',
        image: newProduct.image || editingProduct.image
      };
      setProducts(products.map(p => p.id === editingProduct.id ? updatedProduct : p));
      setIsEditModalOpen(false);
      setEditingProduct(null);
      setNewProduct({
        name: '',
        price: 0,
        pricePerKg: true,
        minPack: 0.5,
        stock: 0,
        category: 'meat'
      });
    }
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts(products.filter(p => p.id !== productId));
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Pending';
      case 'preparing': return 'Preparing';
      case 'shipped': return 'Shipped';
      case 'delivered': return 'Delivered';
      case 'cancelled': return 'Cancelled';
      default: return status;
    }
  };

  return (
    <div className="admin-dashboard">
      <div className="admin-header">
        <h1>Admin Dashboard</h1>
        <button onClick={handleLogout} className="logout-btn">
          <LogOut size={16} />
          Logout
        </button>
      </div>

      <div className="admin-tabs">
        <button 
          className={`tab-btn ${activeTab === 'products' ? 'active' : ''}`}
          onClick={() => setActiveTab('products')}
        >
          <Package size={16} />
          Products
        </button>
        <button 
          className={`tab-btn ${activeTab === 'orders' ? 'active' : ''}`}
          onClick={() => setActiveTab('orders')}
        >
          <ShoppingCart size={16} />
          Orders
        </button>
      </div>

      {activeTab === 'products' && (
        <div className="products-section">
          <div className="section-header">
            <h2>Manage Products</h2>
            <button onClick={() => setIsAddModalOpen(true)} className="add-btn">
              <Plus size={16} />
              Add Product
            </button>
          </div>

          <div className="products-grid">
            {products.map(product => (
              <div key={product.id} className="product-card">
                <div className="product-image">
                  <img src={product.image || '/placeholder-meat.jpg'} alt={product.name} />
                </div>
                <div className="product-info">
                  <h3>{product.name}</h3>
                  <p>€{product.price.toFixed(2)}/kg</p>
                  <p>Min: {product.minPack}kg</p>
                  <p>Stock: {product.stock}kg</p>
                  <p>Category: {product.category}</p>
                </div>
                <div className="product-actions">
                  <button onClick={() => handleEditProduct(product)} className="edit-btn">
                    <Edit size={16} />
                  </button>
                  <button onClick={() => handleDeleteProduct(product.id)} className="delete-btn">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'orders' && (
        <div className="orders-section">
          <h2>Order Management</h2>
          <div className="orders-grid">
            {orders.map(order => (
              <div key={order.id} className="order-card">
                <div className="order-header">
                  <h3>Order #{order.id}</h3>
                  <span className={`status ${order.status}`}>
                    {getStatusText(order.status)}
                  </span>
                </div>
                <div className="order-details">
                  <p><strong>Customer:</strong> User {order.userId}</p>
                  <p><strong>Total:</strong> €{order.total.toFixed(2)}</p>
                  <p><strong>Date:</strong> {order.createdAt.toLocaleDateString()}</p>
                  <p><strong>Status:</strong> {getStatusText(order.status)}</p>
                </div>
                <div className="order-items">
                  {order.items.map((item, index) => (
                    <div key={index} className="order-item">
                      <span>{item.product.name}</span>
                      <span>{item.quantity}kg</span>
                      <span>€{(item.product.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Product Modal */}
      {isAddModalOpen && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Add New Product</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="close-btn">
                <CloseIcon size={20} />
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Name:</label>
                <input
                  type="text"
                  value={newProduct.name}
                  onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                  placeholder="Product name"
                />
              </div>
              <div className="form-group">
                <label>Price (€/kg):</label>
                <input
                  type="number"
                  step="0.01"
                  value={newProduct.price}
                  onChange={(e) => setNewProduct({...newProduct, price: parseFloat(e.target.value)})}
                  placeholder="0.00"
                />
              </div>
              <div className="form-group">
                <label>Minimum Pack (kg):</label>
                <input
                  type="number"
                  step="0.1"
                  value={newProduct.minPack}
                  onChange={(e) => setNewProduct({...newProduct, minPack: parseFloat(e.target.value)})}
                  placeholder="0.5"
                />
              </div>
              <div className="form-group">
                <label>Stock (kg):</label>
                <input
                  type="number"
                  step="0.1"
                  value={newProduct.stock}
                  onChange={(e) => setNewProduct({...newProduct, stock: parseFloat(e.target.value)})}
                  placeholder="0"
                />
              </div>
              <div className="form-group">
                <label>Category:</label>
                <select
                  value={newProduct.category}
                  onChange={(e) => setNewProduct({...newProduct, category: e.target.value as any})}
                >
                  <option value="meat">Meat</option>
                  <option value="pork">Pork</option>
                  <option value="sausages">Sausages</option>
                  <option value="achuras">Achuras</option>
                </select>
              </div>
              <div className="form-group">
                <label>Image URL:</label>
                <input
                  type="text"
                  value={newProduct.image}
                  onChange={(e) => setNewProduct({...newProduct, image: e.target.value})}
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
            <div className="modal-footer">
              <button onClick={() => setIsAddModalOpen(false)} className="cancel-btn">
                Cancel
              </button>
              <button onClick={handleAddProduct} className="save-btn">
                <Save size={16} />
                Add Product
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Product Modal */}
      {isEditModalOpen && editingProduct && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Edit Product</h3>
              <button onClick={() => setIsEditModalOpen(false)} className="close-btn">
                <CloseIcon size={20} />
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Name:</label>
                <input
                  type="text"
                  value={newProduct.name}
                  onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                  placeholder="Product name"
                />
              </div>
              <div className="form-group">
                <label>Price (€/kg):</label>
                <input
                  type="number"
                  step="0.01"
                  value={newProduct.price}
                  onChange={(e) => setNewProduct({...newProduct, price: parseFloat(e.target.value)})}
                  placeholder="0.00"
                />
              </div>
              <div className="form-group">
                <label>Minimum Pack (kg):</label>
                <input
                  type="number"
                  step="0.1"
                  value={newProduct.minPack}
                  onChange={(e) => setNewProduct({...newProduct, minPack: parseFloat(e.target.value)})}
                  placeholder="0.5"
                />
              </div>
              <div className="form-group">
                <label>Stock (kg):</label>
                <input
                  type="number"
                  step="0.1"
                  value={newProduct.stock}
                  onChange={(e) => setNewProduct({...newProduct, stock: parseFloat(e.target.value)})}
                  placeholder="0"
                />
              </div>
              <div className="form-group">
                <label>Category:</label>
                <select
                  value={newProduct.category}
                  onChange={(e) => setNewProduct({...newProduct, category: e.target.value as any})}
                >
                  <option value="meat">Meat</option>
                  <option value="pork">Pork</option>
                  <option value="sausages">Sausages</option>
                  <option value="achuras">Achuras</option>
                </select>
              </div>
              <div className="form-group">
                <label>Image URL:</label>
                <input
                  type="text"
                  value={newProduct.image}
                  onChange={(e) => setNewProduct({...newProduct, image: e.target.value})}
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
            <div className="modal-footer">
              <button onClick={() => setIsEditModalOpen(false)} className="cancel-btn">
                Cancel
              </button>
              <button onClick={handleUpdateProduct} className="save-btn">
                <Save size={16} />
                Update Product
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
