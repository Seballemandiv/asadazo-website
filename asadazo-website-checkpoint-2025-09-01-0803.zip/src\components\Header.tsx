import { useState } from 'react';
import { ShoppingCart, User, ChevronDown } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Header = () => {
  const { user, logout } = useAuth();
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('EN');

  const handleLogout = () => {
    logout();
    setIsUserMenuOpen(false);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="header">
      <div className="header-container">
        {/* Logo */}
        <div className="header-logo">
          <img src="/logo.svg" alt="Asadazo" />
        </div>

        {/* Desktop Navigation */}
        <nav className="header-nav">
          <a href="/" className="nav-link" aria-current="page">Home</a>
          <a href="#products" className="nav-link">Products</a>
          <a href="/about" className="nav-link">About Us</a>
          <a href="/contact" className="nav-link">Contact</a>
          <a href="/on-request" className="nav-link">On Request</a>
        </nav>

        {/* Desktop Actions */}
        <div className="header-actions">
          {/* Language Selector */}
          <div className="language-selector">
            <select 
              className="language-dropdown"
              value={currentLanguage}
              onChange={(e) => setCurrentLanguage(e.target.value)}
            >
              <option value="EN">🇺🇸</option>
              <option value="ES">🇪🇸</option>
              <option value="NL">🇳🇱</option>
            </select>
          </div>

          {/* User Menu */}
          {user ? (
            <div className="user-menu-container">
              <button 
                className="user-menu-button"
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
              >
                <User size={20} />
                <span>Account</span>
                <ChevronDown size={16} />
              </button>
              
              {isUserMenuOpen && (
                <div className="user-dropdown">
                  <a href="/account" className="dropdown-item">
                    <User size={16} />
                    Account
                  </a>
                  <a href="/orders" className="dropdown-item">
                    <ShoppingCart size={16} />
                    Orders
                  </a>
                  <a href="/profile" className="dropdown-item">
                    <User size={16} />
                    Personal Information
                  </a>
                  {user.role === 'admin' && (
                    <a href="/admin" className="dropdown-item">
                      <User size={16} />
                      Admin Panel
                    </a>
                  )}
                  <button onClick={handleLogout} className="dropdown-item logout-item">
                    <User size={16} />
                    Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            <a href="/login" className="login-button">Log in</a>
          )}

          {/* Cart */}
          <button className="cart-button">
            <ShoppingCart size={20} />
            <span className="cart-count">0</span>
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button className="mobile-menu-btn" onClick={toggleMobileMenu}>
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <nav className="mobile-nav">
          <a href="/" className="mobile-nav-link">Home</a>
          <a href="#products" className="mobile-nav-link">Products</a>
          <a href="/about" className="mobile-nav-link">About Us</a>
          <a href="/contact" className="mobile-nav-link">Contact</a>
          <a href="/on-request" className="mobile-nav-link">On Request</a>
          
          {user ? (
            <>
              <a href="/account" className="mobile-nav-link">Account</a>
              <a href="/orders" className="mobile-nav-link">Orders</a>
              <a href="/profile" className="mobile-nav-link">Personal Information</a>
              {user.role === 'admin' && (
                <a href="/admin" className="mobile-nav-link">Admin Panel</a>
              )}
              <button onClick={handleLogout} className="mobile-nav-link logout-button">
                Logout
              </button>
            </>
          ) : (
            <a href="/login" className="mobile-nav-link">Log in</a>
          )}
        </nav>
      )}
    </header>
  );
};

export default Header;
