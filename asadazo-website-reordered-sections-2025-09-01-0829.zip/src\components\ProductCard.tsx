import { ShoppingCart } from 'lucide-react';
import type { Product } from '../types';

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const handleAddToCart = () => {
    // In a real app, this would add to cart
    console.log('Adding to cart:', product);
  };

  return (
    <div className="product-card">
      <div className="product-image">
        <img src={product.image || '/placeholder-meat.jpg'} alt={product.name} />
        <div className="product-overlay">
          <button className="add-to-cart-btn" onClick={handleAddToCart}>
            <ShoppingCart size={16} />
            Add to Cart
          </button>
        </div>
      </div>
      
      <div className="product-info">
        <h3 className="product-name">{product.name}</h3>
        <p className="product-description">{product.description}</p>
        
        <div className="product-details">
          <div className="product-price">
            <span className="price">€{product.price.toFixed(2)}</span>
            {product.pricePerKg && <span className="price-unit">/kg</span>}
          </div>
          
          <div className="product-minimum">
            <span className="min-pack">Min: {product.minPack}kg</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
