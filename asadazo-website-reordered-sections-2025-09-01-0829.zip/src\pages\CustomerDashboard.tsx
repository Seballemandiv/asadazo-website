import { useState } from 'react';
import { Package, CreditCard, User, Plus, Edit, Trash2, MapPin } from 'lucide-react';
import type { Order, PaymentMethod } from '../types';

// Mock data
const MOCK_ORDERS: Order[] = [
  {
    id: '1',
    userId: '2',
    items: [
      {
        product: {
          id: '1',
          name: 'Entraña',
          price: 25.99,
          pricePerKg: true,
          minPack: 0.5,
          stock: 10,
          category: 'meat'
        },
        quantity: 1
      }
    ],
    total: 25.99,
    deliveryFee: 5.00,
    deliveryAddress: {
      street: '123 Main St',
      city: 'Amsterdam',
      postalCode: '1000 AA',
      country: 'Netherlands'
    },
    status: 'delivered',
    createdAt: new Date('2024-01-20'),
    deliveryDate: new Date('2024-01-22'),
    paymentMethod: {
      id: '1',
      type: 'card',
      last4: '1234',
      brand: 'Visa',
      isDefault: true
    }
  },
  {
    id: '2',
    userId: '2',
    items: [
      {
        product: {
          id: '2',
          name: 'Vacío',
          price: 28.99,
          pricePerKg: true,
          minPack: 0.5,
          stock: 8,
          category: 'meat'
        },
        quantity: 1.5
      }
    ],
    total: 43.49,
    deliveryFee: 5.00,
    deliveryAddress: {
      street: '123 Main St',
      city: 'Amsterdam',
      postalCode: '1000 AA',
      country: 'Netherlands'
    },
    status: 'preparing',
    createdAt: new Date('2024-01-25'),
    paymentMethod: {
      id: '1',
      type: 'card',
      last4: '1234',
      brand: 'Visa',
      isDefault: true
    }
  }
];

const MOCK_PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: '1',
    type: 'card',
    last4: '1234',
    brand: 'Visa',
    isDefault: true
  },
  {
    id: '2',
    type: 'card',
    last4: '5678',
    brand: 'American Express',
    isDefault: false
  },
  {
    id: '3',
    type: 'bank_transfer',
    iban: 'NL91ABNA0417164300',
    accountHolder: 'John Doe',
    isDefault: false
  },
  {
    id: '4',
    type: 'klarna',
    isDefault: false
  },
  {
    id: '5',
    type: 'ideal',
    idealBank: 'INGBNL2A',
    isDefault: false
  }
];

type PaymentFormData = {
  type: 'card' | 'bank_transfer' | 'klarna' | 'ideal';
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  cardholderName: string;
  iban: string;
  accountHolder: string;
  idealBank: string;
};

const CustomerDashboard = () => {
  const [activeTab, setActiveTab] = useState<'orders' | 'payment' | 'profile'>('orders');
  const [showAddPaymentModal, setShowAddPaymentModal] = useState(false);
  const [newPaymentMethod, setNewPaymentMethod] = useState<PaymentFormData>({
    type: 'card',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardholderName: '',
    iban: '',
    accountHolder: '',
    idealBank: ''
  });

  const getPaymentMethodIcon = (type: string) => {
    switch (type) {
      case 'card': return <CreditCard size={20} />;
      case 'bank_transfer': return <MapPin size={20} />;
      case 'klarna': return <span className="klarna-icon">K</span>;
      case 'ideal': return <span className="ideal-icon">iDEAL</span>;
      default: return <CreditCard size={20} />;
    }
  };

  const getPaymentMethodDisplay = (method: PaymentMethod) => {
    switch (method.type) {
      case 'card':
        return `${method.brand} •••• ${method.last4}`;
      case 'bank_transfer':
        return `SEPA Transfer •••• ${method.iban?.slice(-4)}`;
      case 'klarna':
        return 'Klarna Pay Later';
      case 'ideal':
        return `iDEAL • ${method.idealBank}`;
      default:
        return 'Unknown';
    }
  };

  const handleAddPaymentMethod = () => {
    // In a real app, this would save to the backend
    console.log('Adding payment method:', newPaymentMethod);
    setShowAddPaymentModal(false);
    setNewPaymentMethod({
      type: 'card',
      cardNumber: '',
      expiryDate: '',
      cvv: '',
      cardholderName: '',
      iban: '',
      accountHolder: '',
      idealBank: ''
    });
  };

  const handleDeletePaymentMethod = (id: string) => {
    // In a real app, this would delete from the backend
    console.log('Deleting payment method:', id);
  };

  const handleSetDefaultPaymentMethod = (id: string) => {
    // In a real app, this would update the backend
    console.log('Setting default payment method:', id);
  };

  return (
    <div className="dashboard-page">
      <div className="dashboard-container">
        <div className="dashboard-header">
          <h1 className="dashboard-title">My Account</h1>
          <button className="logout-button">
            <User size={16} />
            Logout
          </button>
        </div>

        <div className="dashboard-tabs">
          <button 
            className={`tab-button ${activeTab === 'orders' ? 'active' : ''}`}
            onClick={() => setActiveTab('orders')}
          >
            <Package size={16} />
            Orders
          </button>
          <button 
            className={`tab-button ${activeTab === 'payment' ? 'active' : ''}`}
            onClick={() => setActiveTab('payment')}
          >
            <CreditCard size={16} />
            Payment Methods
          </button>
          <button 
            className={`tab-button ${activeTab === 'profile' ? 'active' : ''}`}
            onClick={() => setActiveTab('profile')}
          >
            <User size={16} />
            Profile
          </button>
        </div>

        <div className="dashboard-content">
          {activeTab === 'orders' && (
            <div className="orders-section">
              <h2>My Orders</h2>
              {MOCK_ORDERS.length === 0 ? (
                <div className="empty-state">
                  <Package size={48} />
                  <h3>No orders yet</h3>
                  <p>Start shopping to see your orders here</p>
                </div>
              ) : (
                <div className="orders-list">
                  {MOCK_ORDERS.map(order => (
                    <div key={order.id} className="order-card">
                      <div className="order-header">
                        <div className="order-info">
                          <h3>Order #{order.id}</h3>
                          <p className="order-date">
                            {new Date(order.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="order-status">
                          <span className={`status-badge ${order.status}`}>
                            {order.status}
                          </span>
                        </div>
                      </div>
                      
                      <div className="order-items">
                        {order.items.map((item, index) => (
                          <div key={index} className="order-item">
                            <span>{item.product.name}</span>
                            <span>{item.quantity}kg</span>
                            <span>€{(item.product.price * item.quantity).toFixed(2)}</span>
                          </div>
                        ))}
                      </div>
                      
                      <div className="order-footer">
                        <div className="order-total">
                          <strong>Total: €{order.total.toFixed(2)}</strong>
                        </div>
                        {order.deliveryDate && (
                          <div className="delivery-date">
                            Delivery: {new Date(order.deliveryDate).toLocaleDateString()}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'payment' && (
            <div className="payment-section">
              <div className="section-header">
                <h2>Payment Methods</h2>
                <button 
                  className="add-button"
                  onClick={() => setShowAddPaymentModal(true)}
                >
                  <Plus size={16} />
                  Add Payment Method
                </button>
              </div>

              <div className="payment-methods-list">
                {MOCK_PAYMENT_METHODS.map(method => (
                  <div key={method.id} className="payment-method-card">
                    <div className="payment-method-info">
                      <div className="card-icon">
                        {getPaymentMethodIcon(method.type)}
                      </div>
                      <div className="card-details">
                        <h4>{getPaymentMethodDisplay(method)}</h4>
                        {method.isDefault && (
                          <span className="default-badge">Default</span>
                        )}
                      </div>
                    </div>
                    
                    <div className="payment-method-actions">
                      {!method.isDefault && (
                        <button 
                          className="set-default-button"
                          onClick={() => handleSetDefaultPaymentMethod(method.id)}
                        >
                          Set Default
                        </button>
                      )}
                      <button 
                        className="edit-button"
                        onClick={() => console.log('Edit payment method:', method.id)}
                      >
                        <Edit size={16} />
                      </button>
                      <button 
                        className="delete-button"
                        onClick={() => handleDeletePaymentMethod(method.id)}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'profile' && (
            <div className="profile-section">
              <h2>Personal Information</h2>
              
              <form className="profile-form">
                <div className="form-group">
                  <label>Full Name</label>
                  <input type="text" defaultValue="John Doe" />
                </div>
                
                <div className="form-group">
                  <label>Email</label>
                  <input type="email" defaultValue="john.doe@example.com" />
                </div>
                
                <div className="form-group">
                  <label>Phone</label>
                  <input type="tel" defaultValue="+31 6 12345678" />
                </div>

                <div className="address-section">
                  <h3>Address Information</h3>
                  <div className="address-grid">
                    <div className="form-group">
                      <label>Street</label>
                      <input type="text" defaultValue="123 Main Street" />
                    </div>
                    
                    <div className="form-group">
                      <label>Number</label>
                      <input type="text" defaultValue="42" />
                    </div>
                    
                    <div className="form-group">
                      <label>City</label>
                      <input type="text" defaultValue="Amsterdam" />
                    </div>
                    
                    <div className="form-group">
                      <label>Region/Province</label>
                      <input type="text" defaultValue="North Holland" />
                    </div>
                    
                    <div className="form-group">
                      <label>Postal Code</label>
                      <input type="text" defaultValue="1000 AA" />
                    </div>
                    
                    <div className="form-group">
                      <label>Country</label>
                      <select defaultValue="Netherlands">
                        <option value="Netherlands">Netherlands</option>
                        <option value="Belgium">Belgium</option>
                        <option value="Germany">Germany</option>
                        <option value="France">France</option>
                      </select>
                    </div>
                  </div>
                </div>
                
                <button type="submit" className="save-button">
                  Save Changes
                </button>
              </form>
            </div>
          )}
        </div>
      </div>

      {/* Add Payment Method Modal */}
      {showAddPaymentModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h2>Add Payment Method</h2>
              <button 
                className="close-btn"
                onClick={() => setShowAddPaymentModal(false)}
              >
                ×
              </button>
            </div>
            
            <div className="modal-content">
              <div className="payment-type-selector">
                <button 
                  className={`payment-type-btn ${newPaymentMethod.type === 'card' ? 'active' : ''}`}
                  onClick={() => setNewPaymentMethod(prev => ({ ...prev, type: 'card' }))}
                >
                  <CreditCard size={20} />
                  Credit Card
                </button>
                <button 
                  className={`payment-type-btn ${newPaymentMethod.type === 'bank_transfer' ? 'active' : ''}`}
                  onClick={() => setNewPaymentMethod(prev => ({ ...prev, type: 'bank_transfer' }))}
                >
                  <span className="bank-icon">🏦</span>
                  SEPA Transfer
                </button>
                <button 
                  className={`payment-type-btn ${newPaymentMethod.type === 'klarna' ? 'active' : ''}`}
                  onClick={() => setNewPaymentMethod(prev => ({ ...prev, type: 'klarna' }))}
                >
                  <span className="klarna-icon">K</span>
                  Klarna
                </button>
                <button 
                  className={`payment-type-btn ${newPaymentMethod.type === 'ideal' ? 'active' : ''}`}
                  onClick={() => setNewPaymentMethod(prev => ({ ...prev, type: 'ideal' }))}
                >
                  <span className="ideal-icon">iDEAL</span>
                  iDEAL
                </button>
              </div>

              {newPaymentMethod.type === 'card' && (
                <div className="card-form">
                  <div className="form-row">
                    <div className="form-group">
                      <label>Card Number</label>
                      <input 
                        type="text" 
                        placeholder="1234 5678 9012 3456"
                        value={newPaymentMethod.cardNumber}
                        onChange={(e) => setNewPaymentMethod(prev => ({ ...prev, cardNumber: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="form-row">
                    <div className="form-group">
                      <label>Expiry Date</label>
                      <input 
                        type="text" 
                        placeholder="MM/YY"
                        value={newPaymentMethod.expiryDate}
                        onChange={(e) => setNewPaymentMethod(prev => ({ ...prev, expiryDate: e.target.value }))}
                      />
                    </div>
                    <div className="form-group">
                      <label>CVV</label>
                      <input 
                        type="text" 
                        placeholder="123"
                        value={newPaymentMethod.cvv}
                        onChange={(e) => setNewPaymentMethod(prev => ({ ...prev, cvv: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="form-group">
                    <label>Cardholder Name</label>
                    <input 
                      type="text" 
                      placeholder="John Doe"
                      value={newPaymentMethod.cardholderName}
                      onChange={(e) => setNewPaymentMethod(prev => ({ ...prev, cardholderName: e.target.value }))}
                    />
                  </div>
                </div>
              )}

              {newPaymentMethod.type === 'bank_transfer' && (
                <div className="bank-form">
                  <div className="form-group">
                    <label>IBAN</label>
                    <input 
                      type="text" 
                      placeholder="NL91ABNA0417164300"
                      value={newPaymentMethod.iban}
                      onChange={(e) => setNewPaymentMethod(prev => ({ ...prev, iban: e.target.value }))}
                    />
                  </div>
                  <div className="form-group">
                    <label>Account Holder Name</label>
                    <input 
                      type="text" 
                      placeholder="John Doe"
                      value={newPaymentMethod.accountHolder}
                      onChange={(e) => setNewPaymentMethod(prev => ({ ...prev, accountHolder: e.target.value }))}
                    />
                  </div>
                </div>
              )}

              {newPaymentMethod.type === 'klarna' && (
                <div className="klarna-form">
                  <div className="klarna-info">
                    <p>Pay later with Klarna. No fees, no interest.</p>
                  </div>
                  <div className="klarna-benefits">
                    <ul>
                      <li>Pay in 30 days</li>
                      <li>No fees or interest</li>
                      <li>Secure checkout</li>
                    </ul>
                  </div>
                </div>
              )}

              {newPaymentMethod.type === 'ideal' && (
                <div className="ideal-form">
                  <div className="form-group">
                    <label>Select Bank</label>
                    <select 
                      value={newPaymentMethod.idealBank}
                      onChange={(e) => setNewPaymentMethod(prev => ({ ...prev, idealBank: e.target.value }))}
                    >
                      <option value="">Select your bank</option>
                      <option value="INGBNL2A">ING Bank</option>
                      <option value="RABONL2U">Rabobank</option>
                      <option value="ABNANL2A">ABN AMRO</option>
                      <option value="TRIBNL2U">Triodos Bank</option>
                    </select>
                  </div>
                  <div className="ideal-info">
                    <p>Pay directly from your bank account with iDEAL.</p>
                  </div>
                  <div className="ideal-benefits">
                    <ul>
                      <li>Instant payment</li>
                      <li>No additional fees</li>
                      <li>Secure bank transfer</li>
                    </ul>
                  </div>
                </div>
              )}

              <div className="modal-actions">
                <button 
                  className="cancel-btn"
                  onClick={() => setShowAddPaymentModal(false)}
                >
                  Cancel
                </button>
                <button 
                  className="save-btn"
                  onClick={handleAddPaymentMethod}
                >
                  Add Payment Method
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerDashboard;
